/*

package bptree;

import java.io.*;
import java.util.LinkedList;
import java.util.Queue;

public class BPlusTree

{
	public static void main (String[] args){
		Tree tree = new Tree(5);
	      tree.insert(3,103);
	      tree.insert(18,1018);
	      tree.insert(44,1044);
	      tree.insert(27,1027);
	      tree.insert(38,1038);
	      tree.insert(46,1046);
	       
	      tree.insert(28,1028);
	      tree.insert(67,1067);
	      
	      tree.insert(65,1065);
	      
	      tree.insert(59,1018);
	      tree.insert(73,1044);
	      tree.insert(5,1027);
	      tree.insert(58,1038);
	      
	      tree.insert(42,1046);
	      
	      tree.insert(6,7);
	      
	      tree.insert(4,8);
	      
	      tree.insert(15,9);
	      
	      tree.insert(63,103);
	      tree.insert(96,1018);

	          
	      tree.insert(40,1044);
	      tree.insert(2,1027);
	      tree.insert(19,1038);
	      
	      tree.insert(74,1046);

	      tree.insert(20,7);
	      tree.insert(21,8);
	      tree.insert(22,9);


	      tree.insert(36,103);
	      tree.insert(24,1018);
		tree.insert(103,1018);
	    //tree.search(28);
		*/
/*

	      tree.delete(42);
	      
	      tree.delete(40);
	      
	      tree.delete(59);
	      
	      tree.delete(63);
	      
	      tree.delete(27);
	      
	      tree.delete(58);
	      tree.delete(46);

	      tree.delete(44);
	      
	      tree.delete(67);

	      tree.delete(65);
	      tree.delete(28);

	      tree.delete(74);
	      tree.delete(15);
	      tree.delete(96);

	      tree.delete(73);

	      tree.delete(38);
	      tree.delete(22);

	      tree.delete(21);

	      tree.delete(20);

	      tree.delete(4);
	      //tree.delete(18);

	      //tree.delete(6);
	      //tree.delete(5);
	      *//*

*/
/*
	      tree.delete(96);
	      tree.insert(17,1027);
	      tree.insert(43,1038);
	      tree.insert(7,1046);
	      tree.insert(10,7);
	      tree.insert(8,8);
	      tree.insert(23,9);
	      
	      tree.insert(76,103);
	      tree.insert(71,1018);
	      tree.insert(62,1044);
	      tree.insert(99,1027);
	      tree.insert(92,1038);
	      tree.insert(31,1046);
	      tree.insert(33,7);
	      tree.insert(89,8);
	      tree.insert(88,9);
	      
	      tree.insert(81,103);
	      tree.insert(84,1044);
	      tree.insert(83,1027);
	      tree.insert(85,1038);    
	     *//*


	       Queue<Pair<Node, Integer>> que = new LinkedList<>();
	           que.offer(new Pair<>(tree.root, 0));

	           while (!que.isEmpty()) {
	               Pair<Node, Integer> polled = que.poll();
	               Node node = polled.first;
	               Integer depth = polled.second;

	               for (int i = 0; i < depth; i++)
	                   System.out.print("  ");

	               if (node instanceof NonLeafNode) {
	                   System.out.printf("N#%d \t", node.hashCode() % 1000);

	                   for (Pair<Integer, Node> p : ((NonLeafNode) node).data) {
	                       System.out.printf("(%d, #%d) ", p.first, p.second.hashCode() % 1000);
	                       que.offer(new Pair<>(p.second, depth+1));
	                   }
	                   if (((NonLeafNode) node).right != null) {
	                       System.out.printf(" ($, #%d)", ((NonLeafNode) node).right.hashCode() % 1000);
	                       que.offer(new Pair<>(((NonLeafNode) node).right, depth+1));
	                   }

	               } else if (node instanceof LeafNode) {
	                   System.out.printf("L#%d \t", node.hashCode() % 1000);

	                   for (Pair<Integer, Integer> p : ((LeafNode) node).data)
	                       System.out.printf("(%d, %d) ", p.first, p.second);
	               }
	               
	               System.out.println("");
	           }
	}
}
*/


package bptree;

import java.io.*;

public class BPlusTree

{
	private static BufferedReader br;
	private static BufferedReader br2;

	static void saveTree(String fileName, Tree tree) 
	{
        try {
            FileOutputStream fout = new FileOutputStream(fileName);
            ObjectOutputStream oout = new ObjectOutputStream(fout);
            oout.writeObject(tree);
            oout.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
   
	
   static Tree loadTree(String fileName) 
   {
        Tree tree = null;
        try {
            FileInputStream fin = new FileInputStream(fileName);
            ObjectInputStream oin = new ObjectInputStream(fin);
            tree = (Tree)oin.readObject();
            oin.close();

        } catch (IOException e) {
            e.printStackTrace();

        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }

        return tree;
    }
  
	public static void main (String[] args){
		//
		Tree bpt ;
		int order;
		
		if(args[0] == null){
			System.out.println("NO OPTION!");
			System.exit(1);
		}
		//creation
		if(args[0].matches("-c")){
			if(args[1] == null || args[2] == null){
				System.out.println("Argument lack");
				System.exit(1);
			}
			
			order = Integer.parseInt(args[2]);
			bpt = new Tree(order);
			
			saveTree(args[1],bpt);
			System.out.println("create new file success");
		}
		//insertion
		else if(args[0].matches("-i")){
			if(args[1] == null || args[2] == null){
				System.out.println("Argument lack");
				System.exit(1);
			}
			
			bpt=loadTree(args[1]);//load
			try{
			br = new BufferedReader(new FileReader(args[2]));
			String line;
			while( (line=br.readLine()) != null){
					
					String[] t = line.split(",");
					String t1=t[0];
					String t2=t[1];

					int key = Integer.parseInt(t1);
					int value = Integer.parseInt(t2);
				
					bpt.insert(key, value);
				}
			}catch (IOException e){
				e.printStackTrace();
			}
			
			saveTree(args[1],bpt);//save
		}
		//deletion
		else if(args[0].matches("-d")){
			if(args[1] == null || args[2] == null){
				System.out.println("Argument lack");
				System.exit(1);
			}
			bpt=loadTree(args[1]);//load tree
			try{
			br2 = new BufferedReader(new FileReader(args[2]));
			String line;
			while( (line=br2.readLine()) != null){

					String[] t = line.split(",");
					String t1=t[0];
					//String t2=t[1];

					int key = Integer.parseInt(t1);
					//int value = Integer.parseInt(t2);

					bpt.delete(key);
				}
			}catch(IOException e){
				e.printStackTrace();
			}
			saveTree(args[1],bpt);//save
		}
		//single key search
		else if(args[0].matches("-s")){
			if(args[1] == null || args[2] == null){
				System.out.println("Argument lack");
				System.exit(1);
			}
			bpt=loadTree(args[1]);//load tree
			
			int key = Integer.parseInt(args[2]);
			
			Node pos = bpt.root;

			while(!(pos.isLeaf()))
			{
				boolean find = false;
				
				for(int j=0;j<( (NonLeafNode)pos).data.size(); j++){
				System.out.print( ((NonLeafNode)pos).data.get(j).first );
				System.out.print("  ");
				}
				System.out.println();
					
				for(int i =0;i< ( (NonLeafNode)pos).data.size(); i++)
				{
					if(key < ( (NonLeafNode)pos).data.get(i).first ){
						pos = ( (NonLeafNode)pos).data.get(i).second;
						find = true;
						break;
					}
				}	
				if(!find)
					pos = pos.right;
				}
			
			boolean keyfind= false;
				for(int i=0;i<( (LeafNode)pos).data.size(); i++)
				{
					
					if(  ((LeafNode)pos).data.get(i).first == key )
					{
						keyfind=true;
						System.out.println(((LeafNode)pos).data.get(i).second);
						break;
					}
					
				}
				if(!keyfind){
					System.out.println("NOT FOUND");
				}
				
				
				
				
			}
		
		else if(args[0].matches("-r"))
		{
			if(args[1] == null || args[2] == null|| args[3] == null){
				System.out.println("Argument lack");
				System.exit(1);
			}
			
			bpt=loadTree(args[1]);//load tree
			
			int start = Integer.parseInt(args[2]);
			int end = Integer.parseInt(args[3]);
			
			bpt.searchrange(start, end);
			
			saveTree(args[1],bpt);//save

		}
		
		
	}
	
	
}
