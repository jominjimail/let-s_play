package bptree;

import java.io.*;
import java.util.ArrayList;

public class Tree implements Serializable
{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	Node root;
	int maxsize;
	
	
	Tree(int x)
	{
		maxsize = x;
		root = new LeafNode(x);
	}
	
	//***correct key arrive correct leafnode
	public Node searchLeaf(int key)
	{
		Node pos = root;

			//leafnode while
			while(!(pos.isLeaf()))
			{
				boolean find = false;
				
				for(int i =0;i< ( (NonLeafNode)pos).data.size(); i++)
				{
					if(key < ( (NonLeafNode)pos).data.get(i).first ){
						pos = ( (NonLeafNode)pos).data.get(i).second;
						find = true;
						break;
					}
				}	
				if(!find)
					pos = pos.right;
			}//while
		return pos;
	}
	
	//***search function
	public boolean search(int key)
	{
		Node here = searchLeaf(key);
		
		//in correct leafnode's arr find inserct key
		for(int i=0; i<  ((LeafNode)here).data.size() ;i++ )
		{
			if(((LeafNode)here).data.get(i).first == key )
			{
				return true;
			}
			
		}
		return false;
	}
	
	public void searchrange(int start , int end){
		
		Node here = searchLeaf(start);

		while(true){
			for(int i=0; i<  ((LeafNode)here).data.size() ;i++ )
			{
			if( start <=  ((LeafNode)here).data.get(i).first && ((LeafNode)here).data.get(i).first <= end) //�������� key ��ġ ã��
				{
					System.out.print(((LeafNode)here).data.get(i).first);
					System.out.print("  ");
					System.out.print(((LeafNode)here).data.get(i).second);
					System.out.println();
				}
			
			}
			if(here.right == null){
				break;
			}else{
			here=here.right;
			}
		}
		
	
	}
	
	//***insert
	public void insert(int key, int value){
		
		if(search(key) == true){
			System.out.println("Already exist");
			return ;
		}
		
		Node here = searchLeaf (key); //find correct leafnode
		
		Pair<Integer, Integer> temp = new Pair<Integer, Integer>();
		temp.first=key;
		temp.second=value;
		
		((LeafNode)here).data.add(temp);
		
		((LeafNode)here).data.sort((a1, a2) -> a1.first.compareTo(a2.first));

		if(here.isFull()){
			_split(here);
		}
		
	}
	
	
	//***split function
	public void _split(Node here)
	{
		Node now = here;

		int mid ;
		if(now.maxsize ==2 ){
			mid=0;
		}else{
			mid=(now.maxsize)/2;
		}

		if(now.isLeaf()==true)
		{ 
			
			if( now.parent ==null )
			{ //leafnode root
				//System.out.println("leaf o  root o");
				LeafNode NewNode = new LeafNode(maxsize);
				NonLeafNode PNode = new NonLeafNode(maxsize);
				
				NewNode.setParent(PNode);
				now.setParent(PNode);
				
				PNode.right=now;
				
				//range search
				if(((LeafNode)now).left == null ){
					((LeafNode)now).left=NewNode;
					NewNode.right=now;
				}else{
					((LeafNode)now).left.right=NewNode;
					NewNode.left=((LeafNode)now).left;
					NewNode.right=now;
					((LeafNode)now).left=NewNode;
				}
				
				for(int i=0; i<mid ; i++){
					((LeafNode)NewNode).data.add(((LeafNode)now).data.get(0));
					((LeafNode)now).data.remove(0);
				}

				Pair<Integer, Node> temp = new Pair<Integer, Node>();
				temp.first=((LeafNode)now).data.get(0).first;
				temp.second=NewNode;
				
				((NonLeafNode)PNode).data.add(temp);
				
				((NonLeafNode)PNode).data.sort((a1, a2) -> a1.first.compareTo(a2.first));
				
				if(PNode.isFull()){
					_split(PNode);
				}
				
				this.root = PNode;
				
				
			}
			else
			{ // leafnode not root
				//System.out.println("leaf o  root x");
				LeafNode NewNode = new LeafNode(maxsize) ;
				
				NewNode.setParent(now.getParent()); 
				
				//rangesearch
				if(((LeafNode)now).left == null ){
					NewNode.left=((LeafNode)now).left;
					((LeafNode)now).left=NewNode;
					NewNode.right=now;
				}else{
					((LeafNode)now).left.right=NewNode;
					NewNode.left=((LeafNode)now).left;
					NewNode.right=now;
					((LeafNode)now).left=NewNode;
				}
				
				for(int i=0; i<mid ; i++){
					
					((LeafNode)NewNode).data.add(((LeafNode)now).data.get(0));
					((LeafNode)now).data.remove(0);
				}
				
				Pair<Integer, Node> temp = new Pair<Integer, Node>();
				temp.first=((LeafNode)now).data.get(0).first;
				temp.second=NewNode;
				
				((NonLeafNode)(now.getParent())).data.add(temp);
				
				((NonLeafNode)(now.getParent())).data.sort((a1, a2) -> a1.first.compareTo(a2.first));
				
				if(  ( now.getParent() ).isFull()  ){
					_split((now.getParent()));
				}
			}
			
			
			
		}else
		{
			if(now.parent ==null)
			{ //nonleafnode - root
				//System.out.println("Nonleaf x  root o");
				NonLeafNode NewNode = new NonLeafNode (maxsize) ;
				NonLeafNode PNode = new NonLeafNode (maxsize);
				NewNode.setParent(PNode); 
				now.setParent(PNode);
				
				PNode.right=now;
				
				//
				if(((NonLeafNode)now).left == null ){
				NewNode.left=((NonLeafNode)now).left;
				((NonLeafNode)now).left=NewNode;
				NewNode.rs=now;
				}else{
				((NonLeafNode)now).left.rs=NewNode;
				NewNode.left=((NonLeafNode)now).left;
				NewNode.rs=now;
				((NonLeafNode)now).left=NewNode;
				}
				
				for(int i=0; i<mid ; i++){
					((NonLeafNode)now).data.get(0).second.setParent(NewNode);
					((NonLeafNode)NewNode).data.add(((NonLeafNode)now).data.get(0));
					((NonLeafNode)now).data.remove(0);
				}
				
				NewNode.right=((NonLeafNode)now).data.get(0).second; //NewNode �� right �� ����
				
				Pair<Integer, Node> temp = new Pair<Integer, Node>();
				temp.first=((NonLeafNode)now).data.get(0).first;
				temp.second=NewNode; 
				
				((NonLeafNode)now).data.get(0).second.setParent(NewNode);
				
				((NonLeafNode)now).data.remove(0); //nonleafnode �� 
				
				((NonLeafNode)PNode).data.add(temp);
				
				((NonLeafNode)PNode).data.sort((a1, a2) -> a1.first.compareTo(a2.first));
				
				if(PNode.isFull()){
					_split(PNode);
				}
				
				this.root = PNode;
				
			}
			else
			{ //nonleafnode - not root
				//System.out.println("Nonleaf x root x");
				NonLeafNode NewNode = new NonLeafNode(maxsize) ;
				NewNode.setParent(now.getParent());
				
				for(int i=0; i<mid ; i++){
					((NonLeafNode)now).data.get(0).second.setParent(NewNode);
					((NonLeafNode)NewNode).data.add(((NonLeafNode)now).data.get(0));
					((NonLeafNode)now).data.remove(0);
				}
				
				NewNode.right=((NonLeafNode)now).data.get(0).second;				
				
				if(((NonLeafNode)now).left == null ){
					NewNode.left=((NonLeafNode)now).left;
					((NonLeafNode)now).left=NewNode;
					NewNode.rs=now;
					}else{
					((NonLeafNode)now).left.rs=NewNode;
					NewNode.left=((NonLeafNode)now).left;
					NewNode.rs=now;
					((NonLeafNode)now).left=NewNode;
					}

				Pair<Integer, Node> temp = new Pair<Integer, Node>();
				temp.first=((NonLeafNode)now).data.get(0).first;
				temp.second=NewNode;
				
				((NonLeafNode)(now.getParent())).data.add(temp);
				((NonLeafNode)now).data.get(0).second.setParent(NewNode);
				
				((NonLeafNode)now).data.remove(0);

				((NonLeafNode)(now.getParent())).data.sort((a1, a2) -> a1.first.compareTo(a2.first));
				
				
				if(  ( now.getParent() ).isFull()  ){
					_split((now.getParent()));
				}
			}
		}
	}//_split() finish
	
	public void delete(int key){
		if ( search(key)==false  ) //there is no key in current node
			return ;
		Node box = searchLeaf(key); //find leafnode that has the key
		
		int life = (maxsize-1)/2;

		if( ((LeafNode)box).data.size() > life){
			//System.out.println("simple delete");
			int pos =findkeypos(box,key);
			((LeafNode)box).data.remove(pos);
			int newkey = ((LeafNode)box).data.get(0).first;
			parentUpdate( box.getParent() , key , newkey);
			
		}else {
			underflow(box,key);
		}
		
	}//delete() finish

	public void underflow(Node box,int key){
		int life = (maxsize-1)/2;
		
		if(box.isLeaf()==true)
		{//leafNode
			//you can borrow the key at left node
			if( box.left != null && box.left.getParent() == box.getParent() && ((LeafNode)box.left).data.size() > life)
			{
				//System.out.println("???left borrow");
				int zeroupdate=((LeafNode)box).data.get(0).first;
				
				int pos = findkeypos(box, key);
				((LeafNode)box).data.remove(pos);
				
				((LeafNode)box).data.add(  ((LeafNode)box.left).data.get(((LeafNode)box.left).data.size()-1)  );
				((LeafNode)box).data.sort((a1, a2) -> a1.first.compareTo(a2.first));
				
				((LeafNode)box.left).data.remove( ((LeafNode)box.left).data.size()-1 );
				
				parentUpdate( box.getParent() ,zeroupdate,((LeafNode)box).data.get(0).first );
			}
			//you can borrow the key at right node
			else if(box.right != null && box.right.getParent() == box.getParent() && ((LeafNode)box.right).data.size() > life)
			{
				//System.out.println("right borrow");
				int zeroupdate=((LeafNode)box).data.get(0).first;
				//remember box's first key
				int zeroupdate2=((LeafNode)box.right).data.get(0).first;
				//remember box.right 's first key
				int pos = findkeypos(box, key);
				((LeafNode)box).data.remove(pos);
				
				((LeafNode)box).data.add(  ((LeafNode)box.right).data.get(0));
				((LeafNode)box).data.sort((a1, a2) -> a1.first.compareTo(a2.first));
				
				((LeafNode)box.right).data.remove( ((LeafNode)box.right).data.get(0) );
				
				
				//System.out.printf("%d",((LeafNode)box).data.get(0).first);
				//System.out.println();
				//System.out.printf("%d ",((LeafNode)box.right).data.get(0).first);
				parentUpdate( box.getParent() ,zeroupdate2,((LeafNode)box.right).data.get(0).first );
				parentUpdate( box.getParent() ,zeroupdate,((LeafNode)box).data.get(0).first );
				
			}
			else if( box.left != null && box.left.getParent() == box.getParent() )
			{
				//##################################################
				//Merge left
				System.out.println("left merge");
				int pos =findkeypos(box,key);
				//find the keypos you delete
				int zeroupdate = ((LeafNode)box).data.get(0).first;
				((LeafNode)box).data.remove(pos);
				
				
				if( ((NonLeafNode)box.getParent()).data.size() > life )
				{
					int zeroupdate1 = ((LeafNode)box).data.get(0).first;
					//after remove the key you remeber the box's first key
					parentUpdate( box.getParent(), key , zeroupdate1);
					
					for(int i=0;i< ((LeafNode)box.left).data.size() ;i++){
						((LeafNode)box).data.add( ((LeafNode)box.left).data.get(i) );
					}
					
					((LeafNode)box).data.sort((a1, a2) -> a1.first.compareTo(a2.first));
					
					
					int pos2 = findkeypos(box.getParent() , zeroupdate1);
					
					((NonLeafNode)box.getParent()).data.remove(pos2);
					
					if( box.left.left != null){
						box.left.left.right=box;
					}
					box.left=box.left.left;
						
				}else
				{
					for(int i=0;i< ((LeafNode)box.left).data.size() ;i++){
						((LeafNode)box).data.add( ((LeafNode)box.left).data.get(i) );
					}
					((LeafNode)box).data.sort((a1, a2) -> a1.first.compareTo(a2.first));
					
					
					if( box.left.left != null){
						box.left.left.right=box;
					}
					box.left=box.left.left;
					//System.out.printf("$$$$ %d",((NonLeafNode)box.getParent()).data.size() );
					int pos2=findkeypos(box.getParent(),zeroupdate);
					((NonLeafNode)box.getParent()).data.remove(pos2);
					//System.out.printf("&&&  %d",((NonLeafNode)box.getParent()).data.size() );

					if(((NonLeafNode)box.getParent()).data.size() == 0){
						root=box;
					}else if( ((NonLeafNode)box.getParent()).data.size() <=life ){
						underflow(box.getParent() , maxsize);
					}

				}
				
			}
			else if( box.right != null && box.right.getParent() == box.getParent() )
			{
				//###############################################
				//Merge right
				System.out.println("right merge");
				int pos =findkeypos(box,key);
				//find the pos of delete key
				int zeroupdate = ((LeafNode)box.right).data.get(0).first;
				((LeafNode)box).data.remove(pos);
				
				if( ((NonLeafNode)box.getParent()).data.size() > life )
				{
					int pos2 = ((LeafNode)box.right).data.get(0).first;
					
					for(int i=0;i< ((LeafNode)box).data.size() ;i++){
						((LeafNode)box.right).data.add( ((LeafNode)box).data.get(i) );
					}
					
					((LeafNode)box.right).data.sort((a1, a2) -> a1.first.compareTo(a2.first));
					
					//the key of box.parent == we delete it
					int pos3 = findkeypos(box.getParent() , pos2);
					//
					((NonLeafNode)box.getParent()).data.remove(pos3);
					
					if( box.left != null){
						box.left.right=box.right;
					}
					box.right.left=box.left;
				}else{
					for(int i=0 ;i<((LeafNode)box).data.size() ; i++){
					((LeafNode)box.right).data.add( ((LeafNode)box).data.get(i) );
					}
					
					((LeafNode)box.right).data.sort((a1, a2) -> a1.first.compareTo(a2.first));
					
					if( box.left != null){
						box.left.right=box.right;
					}
					box.right.left=box.left;
					
					int pos2 = findkeypos(box.getParent(),zeroupdate);
					((NonLeafNode)box.getParent()).data.remove(pos2);

					if(((NonLeafNode)box.getParent()).data.size() == 0){
						root=box.right;
					}else if( ((NonLeafNode)box.getParent()).data.size() <=life ){
						underflow(box.getParent() , maxsize);
					}
			}
			
		}
		}//leafNode
		else
		{//NonleafNode
			if( box.left != null && box.left.getParent() == box.getParent() && ((NonLeafNode)box.left).data.size() > life)
			{
				//&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
				System.out.println("Parent left borrow");
				
				int zeroupdate = ((NonLeafNode)box.left).data.get( ((NonLeafNode)box.left).data.size()-1 ).first;
				//the box.left's key == rotation key
				
				Node lefttail = ((NonLeafNode)box.left).right;

				lefttail.setParent(box);

				int pos2 = findkeypos(box.left , zeroupdate);
				
				((NonLeafNode)box.left).right=((NonLeafNode)box.left).data.get(pos2).second; 
				
				((NonLeafNode)box.left).data.remove( ((NonLeafNode)box.left).data.size()-1 );
				//box.left key delete
				int parentpos =0;
				
				for(int i=0;i< ((NonLeafNode)box.getParent()).data.size();i++){
					if(  ((NonLeafNode)box.getParent()).data.get(i).second == box.left ){
						parentpos=i;
					}
				}//find the rotation pos int box.parent
				
				int parentkey = ((NonLeafNode)box.getParent()).data.get(parentpos).first;
				// remeber the key in box.parent == rotation key
				
				Pair<Integer, Node> temp = new Pair<Integer, Node>();
				temp.first=parentkey;
				temp.second=lefttail;
				
				((NonLeafNode)box).data.add(temp);
				((NonLeafNode)box).data.sort((a1, a2) -> a1.first.compareTo(a2.first));

				((NonLeafNode)box.getParent()).data.get(parentpos).first=zeroupdate;
				//rotation
			}
			else if(box.rs != null && box.rs.getParent() == box.getParent() && ((NonLeafNode)box.rs).data.size() > life)
			{	//&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
				System.out.println("Parent right borrow");
				
				int zeroupdate = ((NonLeafNode)box.rs).data.get(0).first;
				//box.rs 's key == rotation key
				
				Node rstail = ((NonLeafNode)box.rs).data.get(0).second;
				rstail.setParent(box);

				((NonLeafNode)box.rs).data.remove( 0 );
				//box.rs 's key delete
				
				int parentpos = 0;
				for(int i=0;i< ((NonLeafNode)box.getParent()).data.size();i++){
					if( ((NonLeafNode)box.getParent()).data.get(i).second == box  ){
						parentpos=i;
					}
				}//find the pos of box.parent == rotation pos
		
				int parentkey = ((NonLeafNode)box.getParent()).data.get(parentpos).first;
				// the key of box.parent == rotation key
				
				Pair<Integer, Node> temp = new Pair<Integer, Node>();
				temp.first=parentkey;
				temp.second=box.right;
				
				((NonLeafNode)box).data.add(temp);
				((NonLeafNode)box).data.sort((a1, a2) -> a1.first.compareTo(a2.first));
				box.right=rstail;
				((NonLeafNode)box.getParent()).data.get(parentpos).first=zeroupdate;
				//rotaion box.parent  / box.rs


				
			}
			else if(box.left != null && box.left.getParent() == box.getParent()){
				System.out.println("Parent left merge");
				int parentpos =0;

				for(int i=0;i< ((NonLeafNode)box.getParent()).data.size();i++){
					if(  ((NonLeafNode)box.getParent()).data.get(i).second == box.left ){
						parentpos=i;
					}
				}//find the rotation pos int box.parent

				int parentkey = ((NonLeafNode)box.getParent()).data.get(parentpos).first;

				((NonLeafNode)box.getParent()).data.remove(parentpos);

				Node lefttail = box.left.right;
				lefttail.setParent(box);

				Pair<Integer, Node> temp = new Pair<Integer, Node>();
				temp.first=parentkey;
				temp.second=lefttail;

				((NonLeafNode)box).data.add(temp);

				for(int i=0;i<((NonLeafNode)box.left).data.size() ;i++){
					((NonLeafNode)box).data.add( ((NonLeafNode)box.left).data.get(i) );
					((NonLeafNode)box.left).data.get(i).second.setParent(box);
				}
				((NonLeafNode)box).data.sort((a1, a2) -> a1.first.compareTo(a2.first));
				if( box.left.left != null){
					box.left.left.right=box;
				}
				box.left=box.left.left;

				if(((NonLeafNode)box.getParent()).data.size() == 0){
					root=box;
				}else if( ((NonLeafNode)box.getParent()).data.size() <=life ){
					underflow(box.getParent() , maxsize);
				}

			}
			else if(box.rs != null && box.rs.getParent() == box.getParent()){
				System.out.println("Parent right merge");

				int parentpos =0;

				for(int i=0;i< ((NonLeafNode)box.getParent()).data.size();i++){
					if(  ((NonLeafNode)box.getParent()).data.get(i).second == box ){
						parentpos=i;
					}
				}//find the rotation pos int box.parent

				int parentkey = ((NonLeafNode)box.getParent()).data.get(parentpos).first;

				((NonLeafNode)box.getParent()).data.remove(parentpos);

				Node rstail = box.right ;
				rstail.setParent(box.rs);

				Pair<Integer, Node> temp = new Pair<Integer, Node>();
				temp.first=parentkey;
				temp.second=rstail;

				((NonLeafNode)box.rs).data.add(temp);

				for(int i=0;i<((NonLeafNode)box).data.size() ;i++){
					((NonLeafNode)box.rs).data.add( ((NonLeafNode)box).data.get(i) );
					(((NonLeafNode)box).data.get(i).second).setParent(box.rs);
				}
				((NonLeafNode)box.rs).data.sort((a1, a2) -> a1.first.compareTo(a2.first));

				if(((NonLeafNode)box.rs.getParent()).data.size() == 0){
					root=box.rs;
				}else if( ((NonLeafNode)box.getParent()).data.size() <=life ){
					underflow(box.getParent() , maxsize);
				}
			}
		}//NonleafNode finish
		
	}
	
	public void parentUpdate(Node parent , int delkey, int newkey){
		while(parent != null ){
			int pos = findkeypos(parent , delkey);
			if(pos==maxsize){
				parent=parent.getParent();
				continue;
			}
			((NonLeafNode)parent).data.get(pos).first = newkey;
			parent=parent.getParent();
		}
	}//parentUpdate()
	
	public int findkeypos(Node node , int delkey){
		if(node.isLeaf()==true){
			for (int i=0; i<((LeafNode)node).data.size() ;i++){
				if( ((LeafNode)node).data.get(i).first == delkey){
					return i;
				}
			}
		}else{
			for (int i=0; i<((NonLeafNode)node).data.size() ;i++){
				if( ((NonLeafNode)node).data.get(i).first == delkey){
					return i;
				}
			}
		}
		return maxsize;
	}//findkeypos()
	
}
