package bptree;
import java.util.*;
import java.io.*;

abstract class Node implements Serializable{
	 
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	public Node right;
	public Node parent;
	public Node left;
	public Node rs;
	public int maxsize;
	
	abstract public boolean isFull();
	abstract public boolean isLeaf();
	
	Node(int x){
		rs=null;
		left=null;
		parent = null;
		right = null;
		maxsize = x;
	}
	
	public void setParent(Node newparent) {
	      this.parent = newparent;
	   }
	public Node getParent() {
	      return parent;
	   }
}

class LeafNode extends Node implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	ArrayList <Pair<Integer, Integer>> data; 

	
	LeafNode(int x){
		super(x);
		data = new ArrayList<Pair<Integer, Integer>>();
	}
	
	public boolean isLeaf(){
		return true;
	}
	
	public boolean isFull(){
		if(data.size() == maxsize)
			return true;
		else
			return false;
	}
}

class NonLeafNode extends Node implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	ArrayList <Pair <Integer,Node>> data;
	
	
	NonLeafNode(int x){
		super(x);
		data = new ArrayList<Pair<Integer, Node>>();
	}
	
	public boolean isLeaf(){
		return false;
	}
	
	public boolean isFull(){
		if(data.size() == maxsize)
			return true;
		else
			return false;
	}
}
